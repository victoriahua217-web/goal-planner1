# 理財目標導航

以理財目標為核心的 PV / FV / PMT 試算網站。純靜態單一頁面，沒有建置步驟，也不需要後端。

## 資料夾結構

```
goal-planner/
├── public/            ← 網站內容（Cloudflare 只會發佈這個資料夾）
│   ├── index.html     整個網站（HTML、CSS、JavaScript）
│   └── _headers       Cloudflare Pages 的安全與快取標頭
├── wrangler.toml      Wrangler 部署設定（輸出資料夾 ./public）
├── .gitignore
└── README.md
```

## 一、上傳到 GitHub

1. 在 GitHub 建立新 repository（例如 `goal-planner`），不要勾選 Add README。
2. 在本資料夾開啟終端機：

```bash
git init
git add .
git commit -m "Initial commit"
git branch -M main
git remote add origin https://github.com/<你的帳號>/goal-planner.git
git push -u origin main
```

不想用指令的話：到 repo 頁面按 Add file → Upload files，把整個資料夾內容（包含 `public` 資料夾）拖進去。

## 二、用 GitHub 連接 Cloudflare Pages（推薦，之後 push 就自動更新）

1. Cloudflare Dashboard → Workers & Pages → Create → Pages → Connect to Git
2. 授權並選擇 `goal-planner` repository
3. 建置設定：
   - Framework preset：None
   - Build command：留空
   - Build output directory：`public`
4. 按 Save and Deploy，完成後得到 `https://goal-planner.pages.dev`
5. 想用自己的網域：專案 → Custom domains → Set up a custom domain

之後每次 `git push` 到 `main`，Cloudflare 會自動重新部署；其他分支會產生預覽網址。

## 三、不用 GitHub，直接上傳（選用）

- Dashboard 的 Upload assets：只拖 `public` 資料夾進去
- 或用 Wrangler：

```bash
npx wrangler pages deploy public --project-name goal-planner
```

## 備註

- 字型由 Google Fonts 載入，使用者需能連網；沒載入時會自動使用系統字型。
- 使用者輸入的目標資料存在各自瀏覽器的 localStorage，不會上傳到伺服器。
- 本專案尚未指定授權條款；若要開源，請自行在 repo 新增 LICENSE。
